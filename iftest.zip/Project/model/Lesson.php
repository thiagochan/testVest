<?php
class Lesson{
    private $id;
    private $title;
    private $description;
    private $url;
    private $moduleId;
    private $user;
}
?>