<?php

class Week{
    private $id;
    private $lessons;
}

?>