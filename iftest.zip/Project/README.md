# Project
Projeto de Finalização de Cruso do curso técnico de desenvolvimento de sistemas.

O projeto que está sendo desenvolvido tem como objetivo ajudar estudantes que desejam ingressar no Instituto Federal do Paraná, 
com foco no aprendizado e revisão das matérias do Ensino Fundamental II. Para que isso aconteça o programa irá conter duas frentes de metodologia: 
um cronograma de estudos, organizado em semanas, com todas as matérias abordadas no concurso vestibular e um plano de estudos gerado dinamicamente -
baseado no relatório de desempenho do aluno diante ao simulado criado pelo sistema - que conterá apenas as matérias que foram mal desempenhadas.

Com o plano de estudos formado, o estudante poderá acessar as aulas recomendadas dos módulos sugeridos pelo relatório e publicar comentários na 
aba “Comentários” que cada uma terá. Sua mensagem poderá ser respondida e curtida por outros usuários

Alunos:
  Andrei Quaresma Pinto,
  Thiago Chan Ortega,
  Maria Eduarda Vitali,
  Arthur Afonso Jung,

Orientadores:
  Daniel Di Dominico,
  Marcela Turim
